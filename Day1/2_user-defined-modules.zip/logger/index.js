console.log("Logged from logger->index.js file");
