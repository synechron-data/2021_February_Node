console.log("Logged from logger->myLogger.js file");
