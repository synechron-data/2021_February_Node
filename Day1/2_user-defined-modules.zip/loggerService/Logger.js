class Logger {
    log(message) {
        console.log(`${message}, logged using Logger class Method`);
    }
}

module.exports = Logger;