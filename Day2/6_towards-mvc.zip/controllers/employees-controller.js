const da = require('../data-access');

exports.index = (req, res) => {
    res.render("employees/index", { pageTitle: "Employees View", empList: da.getAllEmployees() });
}

exports.details = (req, res) => {
    var id = req.params.empid;
    res.render("employees/details", { pageTitle: "Employee Details View", employee: da.getEmployee(id) });
}