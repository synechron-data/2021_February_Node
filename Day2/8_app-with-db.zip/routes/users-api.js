var express = require('express');
var router = express.Router();

const usersApiCtrl = require('../controllers/users-api-controller');

// Authenticated using JWT Authentication

// HTTP GET - /api/users (Get All users)
router.get('/', usersApiCtrl.getUsers);

// HTTP GET - /api/users/:userid  (Get single user by id)
router.get('/:userid', usersApiCtrl.getUser);

// HTTP POST - /api/users (Create an user)
router.post('/', usersApiCtrl.createUser);

// HTTP PUT - /api/users/:userid  (Update an User)
router.put('/:userid', usersApiCtrl.updateUser);

// HTTP DELETE - /api/users/:userid  (Delete an User)
router.delete('/:userid', usersApiCtrl.deleteUser);

module.exports = router;
