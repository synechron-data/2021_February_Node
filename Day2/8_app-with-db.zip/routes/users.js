var express = require('express');
var router = express.Router();

const usersCtrl = require('../controllers/users-controller');

// Authenticated using Username&Password / OAuth / OpenID Authentication (PassportJS)

router.get('/', usersCtrl.index);

router.get('/details/:userid', usersCtrl.details);

router.get('/create', usersCtrl.create_get);

router.post('/create', usersCtrl.create_post);

router.get('/edit/:userid', usersCtrl.edit_get);

router.post('/edit/:userid', usersCtrl.edit_post);

router.get('/delete/:userid', usersCtrl.delete_get);

router.post('/delete/:userid', usersCtrl.delete_post);

module.exports = router;
